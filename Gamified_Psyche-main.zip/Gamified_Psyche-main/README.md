# Gamified Psyche

This is a game written in Lua for the Love2D game engine,
seeking to teach various AP Psychology concepts via
real-world scenarios.

The way this game works overall is by providing an event with 4 choices, then once the choice is picked, the user receives
an explanation of the Psychology term associated with it.

To run this program, download the zip, and extract it into a folder.
Then, run love2d on the Gamified_Psyche folder.
