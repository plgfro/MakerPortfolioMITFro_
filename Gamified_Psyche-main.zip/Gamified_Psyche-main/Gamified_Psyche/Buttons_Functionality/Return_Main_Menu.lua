local Game_Manager = require("Game_Manager")
return function()
    Game_Manager.gui_toggles.credits = false
    Game_Manager.gui_toggles.main_menu = true
end