-- DEV PROCESS:
--[[
* Create Events
    * For simplicity's sake, events will be very barebones.
    * Each event will be formatted this way: {
            Name: (name displayed on the top)
            Description: (what the player can read)
            Decisions: {
                Decision_Objects_1,2,3, and 4
            }

            end_event()
                determine_choice() function (takes in decision number), returns a table of new weights to "merge" with the main table.
    }
    Event_Weights object: {
            table of each event and its current probability. determine_weight() will loop through each event.
            (this is a very inefficient process because of the number of events & the number of redundant ones, too, but it should work for now)
    }
    Player object: {
            name
            description
            predispositions to disorders {
                table of key-value pairs of key being disorder name, value being the current predisposition. disorders that cannot exist with eachother ex: (ADHD AND SCHIZOPHRENIA) will be negated if discovered.
            },
            past_decisions: (provides the event and the decision taken. may not include as it may need to reconstruct the entire probabilities table each iteration, which is strange)
    }
    Game Manager: {
            Handles the primary game logic, functions:
            select_event(Player, Current_Weights) -- Picks an event from the weights table and returns an Event object.
            load_event() -- This loads the event into the game
            evaluate_event_decision() -- This is called when the player clicks a button, recalibrates the Event Weights table, and then returns the event used
    },
    Renderer {
        Handles the gui stuff (the boooring stuff :yawn:)
        Renderer.new_event() -- This takes in an event object and shows the popup screen for an event.
        Renderer.main_menu() -- Shows the main menu... duh?
        Renderer.
    }

]]--

local timers = require("Timer")
local game_manager = require("Game_Manager")
game_manager.gui_toggles.main_menu = true -- Starts as true at the beginning of the game.
local Renderer = require("Renderer")

love.window.setTitle("Gamified Psyche")

function love.mousepressed(x, y, button, touch_screen, presses)
    -- Process if it was a button.
    local coords = {
        ["X"] = x,
        ["Y"] = y
    }
    local potential_button_to_trigger = game_manager.buttons_subsection.buttons[coords]
    if potential_button_to_trigger then
        potential_button_to_trigger.Function()
    end
end

function love.update(delta_time)
    timers.check_alarms(delta_time)
end

function love.draw()
    local resolution = Renderer.get_resolution()
    for gui_name, value in pairs(game_manager.gui_toggles) do -- allows for ease of adding new guis
        if value then
            -- This is the first time i nest an if statement 
            -- in a for loop because its Lua not LuaU :(
            Renderer.load_object(resolution, gui_name)
        end
    end 
    -- Potential issue with this for loop is order (its a dictionary), so either create a separate gui for each possibility of the game menu, and load each one separately, or embed it all into the game.lua.
    -- A possible solution is to create a separate list involving load order, which will be a looping linearly, then taking the value as a key to this dict.
    -- New solution is make the gui innately able to support multiple, and make the guis toggle them.
end
