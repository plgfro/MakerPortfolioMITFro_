return {
  "Pinn De Ryan",
  "Finn Martin",
  "Bruhley Shhhultz",
  "Can Cthulu",
  "Gabby Lavvy",
  "Nikki Dikki",
  "Haniel Daniel",
  "Dashy Washy",
  "Tanini Li",
  "Gabi Delulu",
  "Ama Llama",
  "Juni Bunni",
  "Isa Visa",
  "Johoho Follololo",
  "Rebbie Fioro"
}